import json
import os

# Function to load rules from a file
def load_rules(filename):
    try:
        with open(filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Function to save rules to a file
def save_rules(filename, rules):
    with open(filename, 'w') as file:
        json.dump(rules, file, indent=4)

# Define the initial rules and responses
initial_rules = {
    "hi": "Hello! How can I assist you today?",
    "hello": "Hi there! How can I help you?",
    "how are you": "I'm a chatbot, so I don't have feelings, but I'm here to help you!",
    "what is your name": "I'm a simple chatbot created to assist you.",
    "bye": "Goodbye! Have a great day!",
    "thank you": "You're welcome! Is there anything else I can help you with?",
    "help": "Sure! Please ask me anything, and I'll do my best to assist you."
}

# Chatbot function
def chatbot():
    rules_filename = 'rules.json'
    rules = load_rules(rules_filename)
    rules.update(initial_rules)  # Update with initial rules
    print("Chatbot: Hi! I am a chatbot. Type 'exit' to end the conversation.")
    
    while True:
        user_input = input("You: ").lower()  # Convert user input to lowercase to handle case insensitivity
        
        if user_input == "exit":
            save_rules(rules_filename, rules)  # Save rules before exiting
            print("Chatbot: Goodbye! Have a great day!")
            break
        
        response = None
        for key in rules:
            if key in user_input:
                response = rules[key]
                break
        
        if response:
            print(f"Chatbot: {response}")
        else:
            print("Chatbot: I'm sorry, I don't understand that. Can you please teach me how to respond to this?")
            new_response = input("You: ")
            rules[user_input] = new_response
            save_rules(rules_filename, rules)  # Save rules after learning
            print("Chatbot: Thank you! I've learned something new.")
            print(f"Chatbot: {new_response}")

# Run the chatbot
chatbot()
